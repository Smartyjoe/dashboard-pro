<?php
/**
 * Email Manager
 * Handles all email notifications
 */

if (!defined('ABSPATH')) {
    exit;
}

class WP_Dashboard_Pro_Email_Manager {
    
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Settings instance
     */
    private $settings;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->settings = new WP_Dashboard_Pro_Settings();
        $this->init_hooks();
    }
    
    /**
     * Initialize hooks
     */
    private function init_hooks() {
        // Affiliate notifications
        add_action('wp_dashboard_pro_affiliate_approved', array($this, 'send_affiliate_approved'));
        add_action('wp_dashboard_pro_affiliate_rejected', array($this, 'send_affiliate_rejected'), 10, 2);
        
        // Commission notifications
        add_action('wp_dashboard_pro_commission_created', array($this, 'send_commission_earned'), 10, 3);
        add_action('wp_dashboard_pro_commission_approved', array($this, 'send_commission_approved'));
        
        // Withdrawal notifications
        add_action('wp_dashboard_pro_withdrawal_requested', array($this, 'send_withdrawal_requested'));
        add_action('wp_dashboard_pro_withdrawal_approved', array($this, 'send_withdrawal_approved'));
        add_action('wp_dashboard_pro_withdrawal_rejected', array($this, 'send_withdrawal_rejected'), 10, 2);
    }
    
    /**
     * Send affiliate approved email
     */
    public function send_affiliate_approved($affiliate) {
        if (!$this->settings->get('email_notifications.affiliate_approved')) {
            return;
        }
        
        $user = get_user_by('ID', $affiliate->user_id);
        
        if (!$user) {
            return;
        }
        
        $subject = sprintf('[%s] Affiliate Application Approved', $this->get_site_name());
        
        $message = sprintf(
            "Hi %s,\n\nCongratulations! Your affiliate application has been approved.\n\nYour affiliate code: %s\nCommission rate: %s%%\n\nYou can now start promoting and earning commissions.\n\nBest regards,\n%s",
            $user->display_name,
            $affiliate->affiliate_code,
            $affiliate->commission_rate,
            $this->get_site_name()
        );
        
        $this->send_email($user->user_email, $subject, $message);
    }
    
    /**
     * Send affiliate rejected email
     */
    public function send_affiliate_rejected($affiliate, $reason) {
        if (!$this->settings->get('email_notifications.affiliate_rejected')) {
            return;
        }
        
        $user = get_user_by('ID', $affiliate->user_id);
        
        if (!$user) {
            return;
        }
        
        $subject = sprintf('[%s] Affiliate Application Status', $this->get_site_name());
        
        $message = sprintf(
            "Hi %s,\n\nThank you for your interest in our affiliate program.\n\nUnfortunately, your application has not been approved at this time.\n\n%s\n\nBest regards,\n%s",
            $user->display_name,
            $reason ? "Reason: $reason" : '',
            $this->get_site_name()
        );
        
        $this->send_email($user->user_email, $subject, $message);
    }
    
    /**
     * Send commission earned email
     */
    public function send_commission_earned($commission_id, $order, $affiliate) {
        if (!$this->settings->get('email_notifications.commission_earned')) {
            return;
        }
        
        global $wpdb;
        
        $commission_table = $wpdb->prefix . 'dashboard_pro_commissions';
        $commission = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $commission_table WHERE id = %d",
            $commission_id
        ));
        
        if (!$commission) {
            return;
        }
        
        $user = get_user_by('ID', $affiliate->user_id);
        
        if (!$user) {
            return;
        }
        
        $currency = $this->settings->get('affiliate_currency', 'USD');
        
        $subject = sprintf('[%s] New Commission Earned', $this->get_site_name());
        
        $message = sprintf(
            "Hi %s,\n\nGreat news! You've earned a new commission.\n\nAmount: %s %s\nOrder: #%d\nStatus: %s\n\nKeep up the great work!\n\nBest regards,\n%s",
            $user->display_name,
            $commission->amount,
            $currency,
            $commission->order_id,
            ucfirst($commission->status),
            $this->get_site_name()
        );
        
        $this->send_email($user->user_email, $subject, $message);
    }
    
    /**
     * Send commission approved email
     */
    public function send_commission_approved($commission) {
        // Implementation similar to above
    }
    
    /**
     * Send withdrawal requested email
     */
    public function send_withdrawal_requested($withdrawal_id) {
        if (!$this->settings->get('email_notifications.withdrawal_requested')) {
            return;
        }
        
        global $wpdb;
        
        $withdrawal_table = $wpdb->prefix . 'dashboard_pro_withdrawals';
        $withdrawal = $wpdb->get_row($wpdb->prepare(
            "SELECT w.*, a.user_id FROM $withdrawal_table w
            LEFT JOIN {$wpdb->prefix}dashboard_pro_affiliates a ON w.affiliate_id = a.id
            WHERE w.id = %d",
            $withdrawal_id
        ));
        
        if (!$withdrawal) {
            return;
        }
        
        // Send to admin
        $admin_email = get_option('admin_email');
        $currency = $this->settings->get('affiliate_currency', 'USD');
        
        $subject = sprintf('[%s] New Withdrawal Request', $this->get_site_name());
        
        $message = sprintf(
            "A new withdrawal request has been submitted.\n\nAmount: %s %s\nAffiliate ID: %d\nMethod: %s\n\nPlease review and process this request.",
            $withdrawal->amount,
            $currency,
            $withdrawal->affiliate_id,
            $withdrawal->method
        );
        
        $this->send_email($admin_email, $subject, $message);
        
        // Send to affiliate
        $user = get_user_by('ID', $withdrawal->user_id);
        
        if ($user) {
            $subject = sprintf('[%s] Withdrawal Request Received', $this->get_site_name());
            
            $message = sprintf(
                "Hi %s,\n\nWe have received your withdrawal request.\n\nAmount: %s %s\nStatus: Pending\n\nWe will process your request shortly.\n\nBest regards,\n%s",
                $user->display_name,
                $withdrawal->amount,
                $currency,
                $this->get_site_name()
            );
            
            $this->send_email($user->user_email, $subject, $message);
        }
    }
    
    /**
     * Send withdrawal approved email
     */
    public function send_withdrawal_approved($withdrawal) {
        if (!$this->settings->get('email_notifications.withdrawal_approved')) {
            return;
        }
        
        global $wpdb;
        
        $affiliate_table = $wpdb->prefix . 'dashboard_pro_affiliates';
        $affiliate = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $affiliate_table WHERE id = %d",
            $withdrawal->affiliate_id
        ));
        
        if (!$affiliate) {
            return;
        }
        
        $user = get_user_by('ID', $affiliate->user_id);
        
        if (!$user) {
            return;
        }
        
        $currency = $this->settings->get('affiliate_currency', 'USD');
        
        $subject = sprintf('[%s] Withdrawal Approved', $this->get_site_name());
        
        $message = sprintf(
            "Hi %s,\n\nYour withdrawal request has been approved and is being processed.\n\nAmount: %s %s\nMethod: %s\n\nYou should receive your payment shortly.\n\nBest regards,\n%s",
            $user->display_name,
            $withdrawal->amount,
            $currency,
            $withdrawal->method,
            $this->get_site_name()
        );
        
        $this->send_email($user->user_email, $subject, $message);
    }
    
    /**
     * Send withdrawal rejected email
     */
    public function send_withdrawal_rejected($withdrawal, $reason) {
        if (!$this->settings->get('email_notifications.withdrawal_rejected')) {
            return;
        }
        
        global $wpdb;
        
        $affiliate_table = $wpdb->prefix . 'dashboard_pro_affiliates';
        $affiliate = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $affiliate_table WHERE id = %d",
            $withdrawal->affiliate_id
        ));
        
        if (!$affiliate) {
            return;
        }
        
        $user = get_user_by('ID', $affiliate->user_id);
        
        if (!$user) {
            return;
        }
        
        $currency = $this->settings->get('affiliate_currency', 'USD');
        
        $subject = sprintf('[%s] Withdrawal Request Status', $this->get_site_name());
        
        $message = sprintf(
            "Hi %s,\n\nYour withdrawal request has been reviewed.\n\nAmount: %s %s\nStatus: Rejected\n\n%s\n\nBest regards,\n%s",
            $user->display_name,
            $withdrawal->amount,
            $currency,
            $reason ? "Reason: $reason" : '',
            $this->get_site_name()
        );
        
        $this->send_email($user->user_email, $subject, $message);
    }
    
    /**
     * Send email
     */
    private function send_email($to, $subject, $message) {
        $from_name = $this->settings->get('email_from_name') ?: $this->get_site_name();
        $from_email = $this->settings->get('email_from_address') ?: get_option('admin_email');
        
        $headers = array(
            'Content-Type: text/plain; charset=UTF-8',
            "From: $from_name <$from_email>",
        );
        
        wp_mail($to, $subject, $message, $headers);
    }
    
    /**
     * Get site name
     */
    private function get_site_name() {
        return $this->settings->get('brand_name') ?: get_bloginfo('name');
    }
}
